#!/bin/bash
cd "$(dirname "$0")"
(sleep 1 && open "http://127.0.0.1:8088/index.html") &
python3 -m http.server 8088 --bind 127.0.0.1
